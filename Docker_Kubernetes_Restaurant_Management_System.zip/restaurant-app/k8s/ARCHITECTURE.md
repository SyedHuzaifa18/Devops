# Restaurant Management System - Architecture Documentation

## System Overview

The Restaurant Management System is a cloud-native microservices application designed for managing restaurant operations including user authentication, menu management, order processing, and table reservations.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          External Users/Clients                          │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ HTTP/HTTPS
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         Kubernetes Ingress                               │
│                      (restaurant.local / NodePort 30080)                 │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         API Gateway (Nginx)                              │
│                         Service: api-gateway                             │
│                         Type: NodePort (80:30080)                        │
│                         Replicas: 2                                      │
│                                                                           │
│  Routes:                                                                 │
│  • /              → Frontend Service                                     │
│  • /api/auth/*    → Auth Service                                         │
│  • /api/menu/*    → Menu Service                                         │
│  • /api/order/*   → Order Service                                        │
│  • /api/table/*   → Table Service                                        │
└─────────────────────────────────────────────────────────────────────────┘
                     │              │              │              │
        ┌────────────┘              │              │              └──────────┐
        │                           │              │                         │
        │                           │              │                         │
        ▼                           ▼              ▼                         ▼
┌──────────────┐          ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│   Frontend   │          │Auth Service  │  │Menu Service  │  │Table Service │
│   (Nginx)    │          │  (Node.js)   │  │  (Node.js)   │  │  (Node.js)   │
│              │          │              │  │              │  │              │
│ Service:     │          │ Service:     │  │ Service:     │  │ Service:     │
│ frontend-    │          │ auth-service │  │ menu-service │  │ table-service│
│ service      │          │ ClusterIP    │  │ ClusterIP    │  │ ClusterIP    │
│ Port: 80     │          │ Port: 3001   │  │ Port: 3002   │  │ Port: 3004   │
│ Replicas: 2  │          │ Replicas: 2  │  │ Replicas: 2  │  │ Replicas: 2  │
└──────────────┘          └──────┬───────┘  └──────┬───────┘  └──────┬───────┘
                                 │                 │                 │
                                 │                 │                 │
                           ┌─────▼─────────────────▼─────────────────▼─────┐
                           │          Order Service (Node.js)              │
                           │          Service: order-service               │
                           │          ClusterIP Port: 3003                 │
                           │          Replicas: 2                          │
                           └───────────────────┬───────────────────────────┘
                                               │
                                               │
                   ┌───────────────────────────┼───────────────────────────┐
                   │                           │                           │
                   ▼                           ▼                           ▼
         ┌──────────────────┐      ┌──────────────────┐      ┌──────────────────┐
         │   PostgreSQL     │      │    MongoDB       │      │      Redis       │
         │   (StatefulSet)  │      │  (StatefulSet)   │      │   (Deployment)   │
         │                  │      │                  │      │                  │
         │ Service:         │      │ Service:         │      │ Service:         │
         │ postgres-service │      │ mongo-service    │      │ redis-service    │
         │ Headless/None    │      │ Headless/None    │      │ ClusterIP        │
         │ Port: 5432       │      │ Port: 27017      │      │ Port: 6379       │
         │ Replicas: 1      │      │ Replicas: 1      │      │ Replicas: 1      │
         │                  │      │                  │      │                  │
         │ PVC: postgres-pvc│      │ PVC: mongo-pvc   │      │ No persistence   │
         │ Storage: 5Gi     │      │ Storage: 5Gi     │      │ (cache only)     │
         └──────────────────┘      └──────────────────┘      └──────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                     Configuration Resources                              │
│                                                                           │
│  • ConfigMap: app-config (DB hosts, ports, URLs)                         │
│  • ConfigMap: postgres-init-script (DB initialization SQL)               │
│  • ConfigMap: api-gateway-config (Nginx routing config)                  │
│  • Secret: db-secret (postgres credentials - base64 encoded)             │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                     Persistent Storage                                   │
│                                                                           │
│  • PVC: postgres-pvc → PostgreSQL data (/var/lib/postgresql/data)       │
│  • PVC: mongo-pvc → MongoDB data (/data/db)                             │
└─────────────────────────────────────────────────────────────────────────┘
```

## Service Interactions

### 1. User Access Flow
```
User → Ingress → API Gateway → Frontend Service → User's Browser
```

### 2. Authentication Flow
```
User → API Gateway (/api/auth/*) → Auth Service → PostgreSQL
                                        ↓
                                  JWT Token
                                        ↓
                                  Return to User
```

### 3. Menu Browsing Flow
```
User → API Gateway (/api/menu/*) → Menu Service → MongoDB
                                        ↓
                                  Menu Items
                                        ↓
                                  Return to User
```

### 4. Order Placement Flow
```
User → API Gateway (/api/order/*) → Order Service → PostgreSQL (persist)
                                        ↓
                                    Redis (cache)
                                        ↓
                                  Order Confirmation
                                        ↓
                                  Return to User
```

### 5. Table Reservation Flow
```
User → API Gateway (/api/table/*) → Table Service → PostgreSQL
                                        ↓
                                  Reservation Record
                                        ↓
                                  Return to User
```

## Component Details

### Frontend
- **Technology**: Static HTML/CSS/JavaScript served by Nginx
- **Deployment**: 2 replicas for high availability
- **Service Type**: ClusterIP (internal access only)
- **Features**:
  - User registration/login interface
  - Menu browsing with categories
  - Shopping cart functionality
  - Order placement interface
  - Table reservation system

### API Gateway
- **Technology**: Nginx reverse proxy
- **Deployment**: 2 replicas for load distribution
- **Service Type**: NodePort (external access on port 30080)
- **Responsibilities**:
  - Single entry point for all client requests
  - Routes requests to appropriate microservices
  - Load balancing across service replicas
  - SSL termination (can be configured)

### Microservices

#### Auth Service
- **Port**: 3001
- **Database**: PostgreSQL
- **Responsibilities**:
  - User registration with password hashing (bcrypt)
  - User authentication
  - JWT token generation and validation
  - Session management

#### Menu Service
- **Port**: 3002
- **Database**: MongoDB
- **Responsibilities**:
  - CRUD operations for menu items
  - Category management
  - Item availability tracking
  - Menu search and filtering

#### Order Service
- **Port**: 3003
- **Databases**: PostgreSQL + Redis
- **Responsibilities**:
  - Order creation and tracking
  - Order status management
  - Integration with menu and user data
  - Order caching for performance (30s TTL)

#### Table Service
- **Port**: 3004
- **Database**: PostgreSQL
- **Responsibilities**:
  - Table availability checking
  - Reservation creation and management
  - Reservation status updates
  - Time slot management

### Databases

#### PostgreSQL (StatefulSet)
- **Type**: Relational Database
- **Version**: 15-alpine
- **Storage**: 5Gi PersistentVolume
- **Service**: Headless (stateful pod identity)
- **Tables**:
  - `users` - User accounts and credentials
  - `orders` - Order records with JSONB items
  - `tables` - Restaurant table information
  - `reservations` - Table reservation records
- **Initialization**: Automated via init script ConfigMap

#### MongoDB (StatefulSet)
- **Type**: NoSQL Document Database
- **Version**: 7
- **Storage**: 5Gi PersistentVolume
- **Service**: Headless (stateful pod identity)
- **Collections**:
  - `menu` - Menu items with flexible schema
- **Use Case**: Semi-structured menu data with varying attributes

#### Redis (Deployment)
- **Type**: In-memory Cache
- **Version**: 7-alpine
- **Storage**: Ephemeral (no persistence needed)
- **Service**: ClusterIP
- **Use Case**: Caching frequently accessed order data
- **TTL**: 30 seconds for cache entries

## Kubernetes Resources Summary

### Resource Types Used

| Resource Type | Count | Purpose |
|---------------|-------|---------|
| Deployments | 7 | Auth, Menu, Order, Table, Frontend, API Gateway, Redis |
| StatefulSets | 2 | PostgreSQL, MongoDB |
| Services | 10 | One per component (ClusterIP/NodePort/Headless) |
| ConfigMaps | 3 | App config, DB init, Nginx config |
| Secrets | 1 | Database credentials |
| PVCs | 2 | PostgreSQL and MongoDB storage |
| Ingress | 1 | External HTTP access |

### Service Types

| Service | Type | Purpose |
|---------|------|---------|
| api-gateway | NodePort (30080) | External access point |
| postgres-service | ClusterIP (None/Headless) | Stateful identity |
| mongo-service | ClusterIP (None/Headless) | Stateful identity |
| redis-service | ClusterIP | Internal caching |
| auth-service | ClusterIP | Internal API |
| menu-service | ClusterIP | Internal API |
| order-service | ClusterIP | Internal API |
| table-service | ClusterIP | Internal API |
| frontend-service | ClusterIP | Internal web server |

### Replica Strategy

| Component | Replicas | Rationale |
|-----------|----------|-----------|
| API Gateway | 2 | Load balancing and HA |
| Frontend | 2 | High availability |
| Auth Service | 2 | Handle concurrent logins |
| Menu Service | 2 | Handle browse traffic |
| Order Service | 2 | Handle order processing |
| Table Service | 2 | Handle reservations |
| PostgreSQL | 1 | StatefulSet (can be scaled with proper setup) |
| MongoDB | 1 | StatefulSet (can be scaled with proper setup) |
| Redis | 1 | Single cache instance |

### Resource Limits

**Databases**:
- Requests: 256Mi RAM, 250m CPU
- Limits: 512Mi RAM, 500m CPU

**Microservices**:
- Requests: 128Mi RAM, 100m CPU
- Limits: 256Mi RAM, 200m CPU

**Frontend/Gateway**:
- Requests: 64Mi RAM, 50m CPU
- Limits: 128Mi RAM, 100m CPU

## High Availability Features

1. **Multiple Replicas**: All stateless services run with 2+ replicas
2. **Load Balancing**: Kubernetes Service provides automatic load balancing
3. **Health Checks**: All pods have liveness and readiness probes
4. **Rolling Updates**: Deployments support zero-downtime updates
5. **Persistent Storage**: StatefulSets ensure data persistence across restarts
6. **Service Discovery**: Kubernetes DNS enables automatic service location

## Security Considerations

1. **Secret Management**: Credentials stored in Kubernetes Secrets (base64)
2. **Network Isolation**: ClusterIP services not exposed externally
3. **Password Hashing**: bcrypt for user passwords
4. **JWT Tokens**: Stateless authentication
5. **Resource Limits**: Prevent resource exhaustion attacks
6. **Ingress**: Can be configured with TLS/SSL

## Scalability

The application can be scaled horizontally:

```bash
# Scale microservices
kubectl scale deployment auth-service --replicas=5
kubectl scale deployment menu-service --replicas=5
kubectl scale deployment order-service --replicas=5

# Scale frontend
kubectl scale deployment frontend --replicas=3
kubectl scale deployment api-gateway --replicas=3
```

Databases (StatefulSets) require additional configuration for clustering.

## Monitoring Points

1. **Pod Health**: Liveness/Readiness probes
2. **Service Endpoints**: Kubernetes Service monitoring
3. **Resource Usage**: CPU/Memory metrics
4. **Application Logs**: kubectl logs for each service
5. **Database Connections**: Check StatefulSet pod logs

## Data Persistence Strategy

- **PostgreSQL**: PersistentVolumeClaim (postgres-pvc) - 5Gi
- **MongoDB**: PersistentVolumeClaim (mongo-pvc) - 5Gi
- **Redis**: No persistence (cache only, ephemeral)

Data survives pod restarts but requires backup strategy for disaster recovery.

## Deployment Workflow

1. ConfigMaps and Secrets applied first
2. PVCs created for databases
3. StatefulSets deployed (PostgreSQL, MongoDB)
4. Wait for database readiness
5. Microservices deployed
6. Frontend and API Gateway deployed
7. Ingress configured for external access

## Technology Stack Summary

| Layer | Technology |
|-------|------------|
| Container Orchestration | Kubernetes |
| Container Runtime | Docker |
| Frontend | HTML/CSS/JavaScript + Nginx |
| API Gateway | Nginx |
| Backend Services | Node.js + Express.js |
| Relational DB | PostgreSQL 15 |
| NoSQL DB | MongoDB 7 |
| Cache | Redis 7 |
| Authentication | JWT + bcrypt |
| Ingress Controller | Nginx Ingress |

## Future Enhancements

1. **Database Clustering**: Configure PostgreSQL and MongoDB for HA
2. **Horizontal Pod Autoscaling**: Auto-scale based on CPU/memory
3. **Service Mesh**: Implement Istio for advanced traffic management
4. **Monitoring**: Add Prometheus and Grafana
5. **Logging**: Centralized logging with ELK stack
6. **CI/CD**: Automated deployment pipelines
7. **TLS/SSL**: Enable HTTPS via Ingress
8. **Backup/Restore**: Automated database backups
