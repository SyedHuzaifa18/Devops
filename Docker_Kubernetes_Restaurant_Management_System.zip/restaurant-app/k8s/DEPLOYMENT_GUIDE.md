# Restaurant Management System - Complete Deployment Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Quick Start](#quick-start)
3. [Step-by-Step Deployment](#step-by-step-deployment)
4. [Accessing the Application](#accessing-the-application)
5. [Testing the Application](#testing-the-application)
6. [Monitoring and Troubleshooting](#monitoring-and-troubleshooting)
7. [Cleanup](#cleanup)

## Prerequisites

### Required Software
- **Docker**: For building container images
- **Kubernetes Cluster**: One of the following:
  - Minikube (recommended for local development)
  - Kind (Kubernetes in Docker)
  - Cloud provider (GKE, EKS, AKS)
- **kubectl**: Kubernetes command-line tool
- **Git**: To clone the repository

### Installation Instructions

#### Install Docker
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install docker.io
sudo usermod -aG docker $USER
# Log out and back in for group changes to take effect

# Verify
docker --version
```

#### Install kubectl
```bash
# Download latest release
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"

# Install
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# Verify
kubectl version --client
```

#### Install Minikube (Recommended)
```bash
# Download and install
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
sudo install minikube-linux-amd64 /usr/local/bin/minikube

# Verify
minikube version

# Start Minikube
minikube start --cpus=4 --memory=8192

# Verify cluster is running
kubectl cluster-info
```

#### Enable Ingress (for Minikube)
```bash
minikube addons enable ingress
```

## Quick Start

If you want to get up and running quickly:

```bash
# 1. Navigate to the k8s directory
cd /home/noone/Desktop/Huzifa/restaurant-app/k8s

# 2. Make scripts executable
chmod +x build-images.sh deploy.sh cleanup.sh

# 3. Build all Docker images
./build-images.sh

# 4. Load images to Minikube (if using Minikube)
minikube image load auth-service:latest
minikube image load menu-service:latest
minikube image load order-service:latest
minikube image load table-service:latest
minikube image load frontend:latest

# 5. Deploy to Kubernetes
./deploy.sh

# 6. Access the application
# Get Minikube IP
minikube ip

# Access via NodePort
minikube service api-gateway --url
# Or directly: http://$(minikube ip):30080
```

## Step-by-Step Deployment

### Step 1: Verify Kubernetes Cluster

```bash
# Check if cluster is running
kubectl cluster-info

# Check nodes
kubectl get nodes

# Expected output: At least one node in Ready state
```

### Step 2: Build Docker Images

Navigate to the k8s directory and build all images:

```bash
cd /home/noone/Desktop/Huzifa/restaurant-app/k8s
chmod +x build-images.sh
./build-images.sh
```

This script builds:
- `auth-service:latest`
- `menu-service:latest`
- `order-service:latest`
- `table-service:latest`
- `frontend:latest`

Verify images:
```bash
docker images | grep -E "auth-service|menu-service|order-service|table-service|frontend"
```

### Step 3: Load Images to Minikube

If using Minikube, load the images into the Minikube environment:

```bash
minikube image load auth-service:latest
minikube image load menu-service:latest
minikube image load order-service:latest
minikube image load table-service:latest
minikube image load frontend:latest

# Verify images are loaded
minikube image ls | grep -E "auth-service|menu-service|order-service|table-service|frontend"
```

**Note**: Skip this step if using Kind or cloud providers (they use different image loading methods).

### Step 4: Deploy Configuration Resources

```bash
# Apply ConfigMaps and Secrets
kubectl apply -f config/

# Verify
kubectl get configmaps
kubectl get secrets
```

Expected ConfigMaps:
- `app-config`
- `postgres-init-script`
- `api-gateway-config`

Expected Secrets:
- `db-secret`

### Step 5: Create Persistent Storage

```bash
# Apply PVCs
kubectl apply -f database/pvc-postgres.yaml
kubectl apply -f database/pvc-mongo.yaml

# Verify
kubectl get pvc
```

Expected PVCs:
- `postgres-pvc` (5Gi, Bound or Pending)
- `mongo-pvc` (5Gi, Bound or Pending)

### Step 6: Deploy Databases

```bash
# Apply database deployments
kubectl apply -f database/postgres-init-configmap.yaml
kubectl apply -f database/postgres-statefulset.yaml
kubectl apply -f database/mongo-statefulset.yaml
kubectl apply -f database/redis-deployment.yaml

# Watch pods come up
kubectl get pods -w
```

Wait until all database pods are in Running state:
- `postgres-0`
- `mongo-0`
- `redis-*`

Press Ctrl+C to exit watch mode.

Verify databases are ready:
```bash
kubectl get pods -l app=postgres
kubectl get pods -l app=mongo
kubectl get pods -l app=redis
```

### Step 7: Deploy Microservices

```bash
# Apply all microservice deployments
kubectl apply -f microservices/

# Verify
kubectl get deployments
kubectl get pods -l app=auth-service
kubectl get pods -l app=menu-service
kubectl get pods -l app=order-service
kubectl get pods -l app=table-service
```

Each service should have 2 pods running.

### Step 8: Deploy Frontend and API Gateway

```bash
# Apply frontend and gateway
kubectl apply -f frontend/

# Verify
kubectl get deployments
kubectl get pods -l app=frontend
kubectl get pods -l app=api-gateway
```

### Step 9: Apply Ingress

```bash
# Apply ingress
kubectl apply -f ingress/

# Verify
kubectl get ingress
```

### Step 10: Verify All Resources

```bash
# Check all pods
kubectl get pods

# Check all services
kubectl get services

# Check all deployments
kubectl get deployments

# Check all statefulsets
kubectl get statefulsets

# Summary of all resources
kubectl get all
```

## Accessing the Application

### Method 1: NodePort (Recommended for Minikube)

```bash
# Get Minikube IP
minikube ip

# Access application
# http://<minikube-ip>:30080

# Or use minikube service command
minikube service api-gateway --url

# Open in browser
minikube service api-gateway
```

### Method 2: Port Forwarding

```bash
# Forward port 8080 to api-gateway service
kubectl port-forward service/api-gateway 8080:80

# Access at: http://localhost:8080
```

### Method 3: Ingress (requires host configuration)

```bash
# Get Minikube IP
MINIKUBE_IP=$(minikube ip)

# Add to /etc/hosts
echo "$MINIKUBE_IP restaurant.local" | sudo tee -a /etc/hosts

# Access at: http://restaurant.local
```

## Testing the Application

### 1. Test Frontend Access

```bash
# Get the URL
URL=$(minikube service api-gateway --url)

# Test with curl
curl $URL

# Should return HTML content
```

### 2. Test User Registration

```bash
URL=$(minikube service api-gateway --url)

curl -X POST "$URL/api/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "testpass123",
    "email": "test@example.com"
  }'

# Expected: {"message":"User registered successfully","userId":1}
```

### 3. Test User Login

```bash
curl -X POST "$URL/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "testpass123"
  }'

# Expected: {"message":"Login successful","token":"<jwt-token>"}
```

### 4. Test Menu Service

```bash
curl "$URL/api/menu/"

# Expected: List of menu items
```

### 5. Test Tables Service

```bash
curl "$URL/api/table/"

# Expected: List of available tables
```

### 6. Browser Testing

Open your browser and navigate to the application URL:

1. **Homepage**: Should display the restaurant interface
2. **Registration**: Create a new account
3. **Login**: Sign in with your credentials
4. **Menu**: Browse available menu items
5. **Cart**: Add items to cart
6. **Order**: Place an order
7. **Reservations**: Make a table reservation

## Monitoring and Troubleshooting

### Check Pod Status

```bash
# Get all pods
kubectl get pods

# Watch pod status in real-time
kubectl get pods -w

# Describe a problematic pod
kubectl describe pod <pod-name>
```

### View Logs

```bash
# View logs for a specific pod
kubectl logs <pod-name>

# Follow logs (real-time)
kubectl logs -f <pod-name>

# View logs for all pods of a service
kubectl logs -l app=auth-service --all-containers=true

# View previous logs (if pod crashed)
kubectl logs <pod-name> --previous
```

### Common Issues and Solutions

#### Issue 1: Pods in Pending State

```bash
# Check PVC status
kubectl get pvc

# If PVC is pending, check storage class
kubectl get storageclass

# For Minikube, ensure enough resources
minikube status
```

**Solution**: Increase Minikube resources:
```bash
minikube delete
minikube start --cpus=4 --memory=8192
```

#### Issue 2: Pods in ImagePullBackOff

```bash
# Check pod events
kubectl describe pod <pod-name>
```

**Solution**: Ensure images are loaded to Minikube:
```bash
minikube image load <image-name>:latest
```

#### Issue 3: Database Connection Errors

```bash
# Check database pods
kubectl get pods -l app=postgres
kubectl get pods -l app=mongo

# Check database logs
kubectl logs postgres-0
kubectl logs mongo-0

# Test database connectivity
kubectl exec -it postgres-0 -- psql -U restaurant -d restaurantdb -c "\dt"
kubectl exec -it mongo-0 -- mongosh --eval "db.adminCommand('ping')"
```

#### Issue 4: Service Not Accessible

```bash
# Check service endpoints
kubectl get endpoints

# Check service configuration
kubectl describe service api-gateway

# Test internal connectivity
kubectl run -it --rm debug --image=busybox --restart=Never -- wget -O- http://api-gateway
```

### Health Checks

```bash
# Check if all deployments are ready
kubectl get deployments

# Check if all pods are ready
kubectl get pods

# Check services
kubectl get services

# Check ingress
kubectl get ingress
```

### Database Access

#### PostgreSQL
```bash
# Access PostgreSQL shell
kubectl exec -it postgres-0 -- psql -U restaurant -d restaurantdb

# Inside psql:
\dt          # List tables
\d users     # Describe users table
SELECT * FROM users;
\q           # Quit
```

#### MongoDB
```bash
# Access MongoDB shell
kubectl exec -it mongo-0 -- mongosh

# Inside mongosh:
show dbs
use test
show collections
db.menu.find()
exit
```

#### Redis
```bash
# Access Redis CLI
kubectl exec -it $(kubectl get pod -l app=redis -o jsonpath='{.items[0].metadata.name}') -- redis-cli

# Inside redis-cli:
PING
KEYS *
exit
```

## Scaling

### Scale Deployments

```bash
# Scale auth service to 5 replicas
kubectl scale deployment auth-service --replicas=5

# Scale all microservices
kubectl scale deployment auth-service --replicas=3
kubectl scale deployment menu-service --replicas=3
kubectl scale deployment order-service --replicas=3
kubectl scale deployment table-service --replicas=3

# Scale frontend
kubectl scale deployment frontend --replicas=3
kubectl scale deployment api-gateway --replicas=3

# Verify
kubectl get pods
```

### Auto-scaling (HPA)

```bash
# Enable metrics server (for Minikube)
minikube addons enable metrics-server

# Create horizontal pod autoscaler
kubectl autoscale deployment auth-service --cpu-percent=50 --min=2 --max=10

# Check HPA status
kubectl get hpa
```

## Cleanup

### Complete Cleanup

```bash
# Use cleanup script
cd /home/noone/Desktop/Huzifa/restaurant-app/k8s
chmod +x cleanup.sh
./cleanup.sh
```

### Manual Cleanup

```bash
# Delete in reverse order
kubectl delete -f ingress/
kubectl delete -f frontend/
kubectl delete -f microservices/
kubectl delete -f database/
kubectl delete -f config/

# Verify cleanup
kubectl get all
```

### Delete Minikube Cluster

```bash
# Stop Minikube
minikube stop

# Delete Minikube cluster (complete removal)
minikube delete

# Remove all local data
rm -rf ~/.minikube
```

## Performance Tuning

### Resource Monitoring

```bash
# Enable metrics server
minikube addons enable metrics-server

# Check resource usage
kubectl top pods
kubectl top nodes
```

### Adjust Resource Limits

Edit deployment files to adjust resource requests/limits based on your needs.

For example, for auth-service:
```yaml
resources:
  requests:
    memory: "256Mi"
    cpu: "200m"
  limits:
    memory: "512Mi"
    cpu: "400m"
```

Apply changes:
```bash
kubectl apply -f microservices/auth-service-deployment.yaml
```

## Backup and Restore

### Backup PostgreSQL

```bash
# Backup database
kubectl exec postgres-0 -- pg_dump -U restaurant restaurantdb > backup.sql

# Copy from pod to local
kubectl cp postgres-0:/tmp/backup.sql ./backup.sql
```

### Restore PostgreSQL

```bash
# Copy backup to pod
kubectl cp ./backup.sql postgres-0:/tmp/backup.sql

# Restore
kubectl exec -it postgres-0 -- psql -U restaurant -d restaurantdb -f /tmp/backup.sql
```

### Backup MongoDB

```bash
# Backup MongoDB
kubectl exec mongo-0 -- mongodump --out=/tmp/backup

# Copy from pod
kubectl cp mongo-0:/tmp/backup ./mongo-backup
```

## Next Steps

1. **Configure SSL/TLS**: Add certificates to Ingress for HTTPS
2. **Set up monitoring**: Deploy Prometheus and Grafana
3. **Implement CI/CD**: Automate deployment with Jenkins/GitLab CI
4. **Add logging**: Deploy ELK stack for centralized logging
5. **Database clustering**: Configure PostgreSQL and MongoDB for HA
6. **Service mesh**: Implement Istio for advanced traffic management

## Support

For issues or questions:
1. Check logs: `kubectl logs <pod-name>`
2. Describe resources: `kubectl describe <resource-type> <resource-name>`
3. Check events: `kubectl get events --sort-by=.metadata.creationTimestamp`
4. Review documentation in `README.md` and `ARCHITECTURE.md`

## Appendix: Useful Commands

```bash
# Get cluster info
kubectl cluster-info

# Get all resources
kubectl get all

# Get resources in all namespaces
kubectl get all --all-namespaces

# Get pod YAML
kubectl get pod <pod-name> -o yaml

# Execute command in pod
kubectl exec -it <pod-name> -- /bin/sh

# Copy files to/from pod
kubectl cp <local-path> <pod-name>:<pod-path>
kubectl cp <pod-name>:<pod-path> <local-path>

# Port forward to service
kubectl port-forward service/<service-name> <local-port>:<service-port>

# Get events
kubectl get events --sort-by=.metadata.creationTimestamp

# Delete pod (will be recreated by deployment)
kubectl delete pod <pod-name>

# Restart deployment
kubectl rollout restart deployment <deployment-name>

# Check rollout status
kubectl rollout status deployment <deployment-name>

# View rollout history
kubectl rollout history deployment <deployment-name>

# Undo rollout
kubectl rollout undo deployment <deployment-name>
```
