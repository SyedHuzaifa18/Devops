# Restaurant Management System - Kubernetes Deployment

This directory contains all Kubernetes manifests and deployment scripts for the Restaurant Management System.

## Architecture Overview

The application consists of:
- **Frontend**: Nginx serving static HTML/CSS/JS
- **API Gateway**: Nginx reverse proxy routing requests
- **Microservices**:
  - Auth Service (Node.js) - User authentication
  - Menu Service (Node.js) - Menu management
  - Order Service (Node.js) - Order processing
  - Table Service (Node.js) - Table reservations
- **Databases**:
  - PostgreSQL (StatefulSet) - Relational data
  - MongoDB (StatefulSet) - Menu items
  - Redis (Deployment) - Caching layer

## Directory Structure

```
k8s/
├── config/                 # ConfigMaps and Secrets
│   ├── configmap.yaml
│   └── secrets.yaml
├── database/               # Database resources
│   ├── pvc-postgres.yaml
│   ├── pvc-mongo.yaml
│   ├── postgres-init-configmap.yaml
│   ├── postgres-statefulset.yaml
│   ├── mongo-statefulset.yaml
│   └── redis-deployment.yaml
├── microservices/          # Microservice deployments
│   ├── auth-service-deployment.yaml
│   ├── menu-service-deployment.yaml
│   ├── order-service-deployment.yaml
│   └── table-service-deployment.yaml
├── frontend/               # Frontend and API Gateway
│   ├── frontend-deployment.yaml
│   ├── api-gateway-configmap.yaml
│   └── api-gateway-deployment.yaml
├── ingress/                # Ingress resources
│   └── ingress.yaml
├── deploy.sh               # Deployment script
├── cleanup.sh              # Cleanup script
└── build-images.sh         # Docker image build script
```

## Prerequisites

1. **Kubernetes Cluster** (choose one):
   - Minikube: `minikube start`
   - Kind: `kind create cluster`
   - Cloud provider (GKE, EKS, AKS)

2. **kubectl** installed and configured

3. **Docker** for building images

4. **Nginx Ingress Controller** (for Ingress support):
   ```bash
   # For Minikube
   minikube addons enable ingress

   # For other clusters
   kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.8.1/deploy/static/provider/cloud/deploy.yaml
   ```

## Deployment Steps

### Step 1: Build Docker Images

```bash
cd k8s
chmod +x build-images.sh
./build-images.sh
```

### Step 2: Load Images to Minikube (if using Minikube)

```bash
minikube image load auth-service:latest
minikube image load menu-service:latest
minikube image load order-service:latest
minikube image load table-service:latest
minikube image load frontend:latest
```

### Step 3: Deploy to Kubernetes

```bash
chmod +x deploy.sh
./deploy.sh
```

### Step 4: Access the Application

**Option 1: NodePort (Port 30080)**
```bash
# For Minikube
minikube service api-gateway --url

# Direct access
http://localhost:30080
```

**Option 2: Ingress (restaurant.local)**
```bash
# Add to /etc/hosts
echo "127.0.0.1 restaurant.local" | sudo tee -a /etc/hosts

# For Minikube, get the IP
minikube ip
# Add: <minikube-ip> restaurant.local to /etc/hosts

# Access
http://restaurant.local
```

## Kubernetes Resources

### ConfigMaps
- `app-config`: Application configuration (database hosts, ports)
- `postgres-init-script`: PostgreSQL initialization SQL
- `api-gateway-config`: Nginx configuration for API Gateway

### Secrets
- `db-secret`: Database credentials (base64 encoded)
  - `postgres-user`: restaurant
  - `postgres-password`: password

### PersistentVolumeClaims
- `postgres-pvc`: 5Gi for PostgreSQL data
- `mongo-pvc`: 5Gi for MongoDB data

### StatefulSets
- `postgres`: PostgreSQL 15 database
- `mongo`: MongoDB 7 database

### Deployments
- `redis`: Redis cache (1 replica)
- `auth-service`: Authentication service (2 replicas)
- `menu-service`: Menu management (2 replicas)
- `order-service`: Order processing (2 replicas)
- `table-service`: Table reservations (2 replicas)
- `frontend`: Web frontend (2 replicas)
- `api-gateway`: API Gateway/Reverse Proxy (2 replicas)

### Services
- `postgres-service`: ClusterIP (Headless)
- `mongo-service`: ClusterIP (Headless)
- `redis-service`: ClusterIP
- `auth-service`: ClusterIP
- `menu-service`: ClusterIP
- `order-service`: ClusterIP
- `table-service`: ClusterIP
- `frontend-service`: ClusterIP
- `api-gateway`: NodePort (30080)

### Ingress
- `restaurant-ingress`: Routes traffic to api-gateway

## Monitoring and Troubleshooting

### Check Pod Status
```bash
kubectl get pods
kubectl get pods -w  # Watch mode
```

### View Logs
```bash
# View logs for a specific pod
kubectl logs <pod-name>

# Follow logs
kubectl logs -f <pod-name>

# View logs for all pods of a service
kubectl logs -l app=auth-service
```

### Describe Resources
```bash
kubectl describe pod <pod-name>
kubectl describe service <service-name>
kubectl describe ingress restaurant-ingress
```

### Execute Commands in Pods
```bash
# PostgreSQL
kubectl exec -it postgres-0 -- psql -U restaurant -d restaurantdb

# MongoDB
kubectl exec -it mongo-0 -- mongosh

# Redis
kubectl exec -it <redis-pod-name> -- redis-cli
```

### Port Forwarding (for debugging)
```bash
kubectl port-forward service/auth-service 3001:3001
kubectl port-forward service/frontend-service 8080:80
kubectl port-forward service/postgres-service 5432:5432
```

## Resource Limits

All services have resource requests and limits configured:

**Databases**:
- PostgreSQL/MongoDB: 256Mi-512Mi memory, 250m-500m CPU
- Redis: 128Mi-256Mi memory, 100m-200m CPU

**Microservices**:
- Each service: 128Mi-256Mi memory, 100m-200m CPU

**Frontend/Gateway**:
- Each: 64Mi-128Mi memory, 50m-100m CPU

## Health Checks

All services have liveness and readiness probes configured:
- **Databases**: Command-based health checks
- **Services**: HTTP health check endpoints
- **Initial Delay**: 5-30 seconds
- **Period**: 5-10 seconds

## Cleanup

To remove all deployed resources:

```bash
chmod +x cleanup.sh
./cleanup.sh
```

This will delete all deployments, services, configmaps, secrets, and PVCs.

## Manual Deployment

If you prefer to deploy manually:

```bash
# 1. Apply configs
kubectl apply -f config/

# 2. Apply PVCs
kubectl apply -f database/pvc-postgres.yaml
kubectl apply -f database/pvc-mongo.yaml

# 3. Deploy databases
kubectl apply -f database/postgres-init-configmap.yaml
kubectl apply -f database/postgres-statefulset.yaml
kubectl apply -f database/mongo-statefulset.yaml
kubectl apply -f database/redis-deployment.yaml

# Wait for databases to be ready
kubectl wait --for=condition=ready pod -l app=postgres --timeout=300s
kubectl wait --for=condition=ready pod -l app=mongo --timeout=300s

# 4. Deploy microservices
kubectl apply -f microservices/

# 5. Deploy frontend
kubectl apply -f frontend/

# 6. Apply ingress
kubectl apply -f ingress/
```

## Scaling

To scale services:

```bash
kubectl scale deployment auth-service --replicas=3
kubectl scale deployment menu-service --replicas=3
kubectl scale deployment order-service --replicas=3
kubectl scale deployment table-service --replicas=3
kubectl scale deployment frontend --replicas=3
kubectl scale deployment api-gateway --replicas=3
```

## Service Endpoints

Once deployed, services are accessible internally at:
- `postgres-service:5432`
- `mongo-service:27017`
- `redis-service:6379`
- `auth-service:3001`
- `menu-service:3002`
- `order-service:3003`
- `table-service:3004`
- `frontend-service:80`
- `api-gateway:80`

## External Access Points

- **NodePort**: `http://localhost:30080` or `http://<node-ip>:30080`
- **Ingress**: `http://restaurant.local` (requires /etc/hosts entry)
- **Minikube**: `minikube service api-gateway --url`

## Notes

- All passwords are stored in Kubernetes Secrets (base64 encoded)
- Database data persists via PersistentVolumeClaims
- Services use Kubernetes DNS for service discovery
- API Gateway routes all external traffic to appropriate services
- StatefulSets ensure ordered deployment and stable network identities for databases
- Health checks ensure pods are ready before receiving traffic
