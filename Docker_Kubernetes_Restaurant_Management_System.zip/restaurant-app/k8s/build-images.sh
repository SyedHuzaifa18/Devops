#!/bin/bash

# Build all Docker images for the Restaurant Management System
# Use this script before deploying to Kubernetes

set -e

echo "========================================="
echo "Building Docker Images"
echo "========================================="

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Navigate to parent directory
cd ..

echo -e "${YELLOW}Building auth-service...${NC}"
docker build -t auth-service:latest ./auth-service

echo -e "${YELLOW}Building menu-service...${NC}"
docker build -t menu-service:latest ./menu-service

echo -e "${YELLOW}Building order-service...${NC}"
docker build -t order-service:latest ./order-service

echo -e "${YELLOW}Building table-service...${NC}"
docker build -t table-service:latest ./table-service

echo -e "${YELLOW}Building frontend...${NC}"
docker build -t frontend:latest ./frontend

echo ""
echo -e "${GREEN}All images built successfully!${NC}"
echo ""
echo "Images:"
docker images | grep -E "auth-service|menu-service|order-service|table-service|frontend" || true
echo ""
echo "Note: For Minikube, load images with:"
echo "minikube image load <image-name>:latest"
echo ""
echo "For example:"
echo "minikube image load auth-service:latest"
echo "minikube image load menu-service:latest"
echo "minikube image load order-service:latest"
echo "minikube image load table-service:latest"
echo "minikube image load frontend:latest"
