#!/bin/bash

# Restaurant Management System - Kubernetes Cleanup Script
# This script removes all deployed resources

set -e

echo "========================================="
echo "Restaurant Management System - K8s Cleanup"
echo "========================================="

RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${RED}WARNING: This will delete all deployed resources!${NC}"
read -p "Are you sure you want to continue? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    echo "Cleanup cancelled."
    exit 0
fi

echo "Deleting Ingress..."
kubectl delete -f ingress/ --ignore-not-found=true

echo "Deleting Frontend and API Gateway..."
kubectl delete -f frontend/ --ignore-not-found=true

echo "Deleting Microservices..."
kubectl delete -f microservices/ --ignore-not-found=true

echo "Deleting Databases..."
kubectl delete -f database/redis-deployment.yaml --ignore-not-found=true
kubectl delete -f database/mongo-statefulset.yaml --ignore-not-found=true
kubectl delete -f database/postgres-statefulset.yaml --ignore-not-found=true
kubectl delete -f database/postgres-init-configmap.yaml --ignore-not-found=true

echo "Deleting PVCs..."
kubectl delete -f database/pvc-mongo.yaml --ignore-not-found=true
kubectl delete -f database/pvc-postgres.yaml --ignore-not-found=true

echo "Deleting ConfigMaps and Secrets..."
kubectl delete -f config/ --ignore-not-found=true

echo ""
echo "Cleanup completed!"
echo ""
echo "To verify all resources are deleted:"
echo "kubectl get all"
