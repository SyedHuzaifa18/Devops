#!/bin/bash

# Restaurant Management System - Kubernetes Deployment Script
# This script deploys the entire application to a Kubernetes cluster

set -e

echo "========================================="
echo "Restaurant Management System - K8s Deploy"
echo "========================================="

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Step 1: Creating namespace (if needed)${NC}"
kubectl create namespace default --dry-run=client -o yaml | kubectl apply -f -

echo -e "${YELLOW}Step 2: Applying ConfigMaps and Secrets${NC}"
kubectl apply -f config/

echo -e "${YELLOW}Step 3: Applying PersistentVolumeClaims${NC}"
kubectl apply -f database/pvc-postgres.yaml
kubectl apply -f database/pvc-mongo.yaml

echo -e "${YELLOW}Step 4: Deploying Databases (StatefulSets)${NC}"
kubectl apply -f database/postgres-init-configmap.yaml
kubectl apply -f database/postgres-statefulset.yaml
kubectl apply -f database/mongo-statefulset.yaml
kubectl apply -f database/redis-deployment.yaml

echo -e "${YELLOW}Waiting for databases to be ready (30 seconds)...${NC}"
sleep 30

echo -e "${YELLOW}Step 5: Deploying Microservices${NC}"
kubectl apply -f microservices/

echo -e "${YELLOW}Step 6: Deploying Frontend and API Gateway${NC}"
kubectl apply -f frontend/

echo -e "${YELLOW}Step 7: Applying Ingress${NC}"
kubectl apply -f ingress/

echo ""
echo -e "${GREEN}Deployment completed!${NC}"
echo ""
echo "========================================="
echo "Checking deployment status..."
echo "========================================="
kubectl get pods
echo ""
kubectl get services
echo ""
echo "========================================="
echo "Access the application:"
echo "========================================="
echo "1. NodePort: http://localhost:30080"
echo "2. Ingress: http://restaurant.local (add to /etc/hosts)"
echo ""
echo "To add to /etc/hosts:"
echo "echo '127.0.0.1 restaurant.local' | sudo tee -a /etc/hosts"
echo ""
echo "To monitor pods:"
echo "kubectl get pods -w"
echo ""
echo "To view logs:"
echo "kubectl logs -f <pod-name>"
echo "========================================="
