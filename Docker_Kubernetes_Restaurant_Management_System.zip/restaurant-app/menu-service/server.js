const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const MONGO_URL = process.env.MONGO_URL || 'mongodb://mongo:27017';
const client = new MongoClient(MONGO_URL);
let db;

// Connect to MongoDB
async function connectDB() {
  try {
    await client.connect();
    db = client.db('restaurantdb');
    console.log('Menu Service: Connected to MongoDB');

    // Insert sample data if empty
    const count = await db.collection('menu').countDocuments();
    if (count === 0) {
      await db.collection('menu').insertMany([
        { name: 'Burger', price: 450, category: 'Main Course', available: true },
        { name: 'Pizza', price: 850, category: 'Main Course', available: true },
        { name: 'Pasta', price: 650, category: 'Main Course', available: true },
        { name: 'Biryani', price: 550, category: 'Main Course', available: true },
        { name: 'Karahi', price: 950, category: 'Main Course', available: true },
        { name: 'Salad', price: 250, category: 'Starter', available: true },
        { name: 'Samosa (2 pcs)', price: 100, category: 'Starter', available: true },
        { name: 'Ice Cream', price: 200, category: 'Dessert', available: true },
        { name: 'Gulab Jamun', price: 150, category: 'Dessert', available: true },
        { name: 'Cold Drink', price: 80, category: 'Beverage', available: true },
      ]);
      console.log('Sample menu items added (PKR)');
    }
  } catch (err) {
    console.error('MongoDB connection error:', err);
    setTimeout(connectDB, 3000);
  }
}

// Get all menu items
app.get('/menu', async (req, res) => {
  try {
    const items = await db.collection('menu').find({}).toArray();
    res.json({ success: true, items });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get menu item by ID
app.get('/menu/:id', async (req, res) => {
  try {
    const item = await db.collection('menu').findOne({ _id: new ObjectId(req.params.id) });
    if (!item) {
      return res.status(404).json({ success: false, error: 'Item not found' });
    }
    res.json({ success: true, item });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Add menu item
app.post('/menu', async (req, res) => {
  try {
    const { name, price, category, available } = req.body;
    const result = await db.collection('menu').insertOne({ name, price, category, available: available !== false });
    res.json({ success: true, id: result.insertedId });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Update menu item
app.put('/menu/:id', async (req, res) => {
  try {
    const { name, price, category, available } = req.body;
    await db.collection('menu').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: { name, price, category, available } }
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Delete menu item
app.delete('/menu/:id', async (req, res) => {
  try {
    await db.collection('menu').deleteOne({ _id: new ObjectId(req.params.id) });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'menu-service' });
});

const PORT = 3002;
app.listen(PORT, () => {
  console.log(`Menu Service running on port ${PORT}`);
  setTimeout(connectDB, 2000);
});
