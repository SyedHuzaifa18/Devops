const express = require('express');
const { Pool } = require('pg');
const redis = require('redis');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const pool = new Pool({
  host: process.env.DB_HOST || 'postgres',
  user: process.env.DB_USER || 'restaurant',
  password: process.env.DB_PASSWORD || 'password',
  database: process.env.DB_NAME || 'restaurantdb',
  port: 5432,
});

let redisClient;
async function initRedis() {
  try {
    redisClient = redis.createClient({
      url: 'redis://redis:6379'
    });
    await redisClient.connect();
    console.log('Order Service: Connected to Redis');
  } catch (err) {
    console.error('Redis connection error:', err);
  }
}

// Initialize database
async function initDB() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS orders (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        items TEXT NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('Order Service: Database initialized');
  } catch (err) {
    console.error('Database init error:', err);
  }
}

// Create order
app.post('/orders', async (req, res) => {
  try {
    const { user_id, items, total_amount } = req.body;

    const result = await pool.query(
      'INSERT INTO orders (user_id, items, total_amount) VALUES ($1, $2, $3) RETURNING *',
      [user_id, JSON.stringify(items), total_amount]
    );

    // Clear cache
    if (redisClient) {
      await redisClient.del('all_orders');
    }

    res.json({ success: true, order: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get all orders
app.get('/orders', async (req, res) => {
  try {
    // Try cache first
    if (redisClient) {
      const cached = await redisClient.get('all_orders');
      if (cached) {
        return res.json({ success: true, orders: JSON.parse(cached), cached: true });
      }
    }

    const result = await pool.query('SELECT * FROM orders ORDER BY created_at DESC');

    // Cache for 30 seconds
    if (redisClient) {
      await redisClient.setEx('all_orders', 30, JSON.stringify(result.rows));
    }

    res.json({ success: true, orders: result.rows, cached: false });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get order by ID
app.get('/orders/:id', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM orders WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Order not found' });
    }
    res.json({ success: true, order: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Update order status
app.put('/orders/:id', async (req, res) => {
  try {
    const { status } = req.body;
    await pool.query('UPDATE orders SET status = $1 WHERE id = $2', [status, req.params.id]);

    // Clear cache
    if (redisClient) {
      await redisClient.del('all_orders');
    }

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'order-service' });
});

const PORT = 3003;
app.listen(PORT, () => {
  console.log(`Order Service running on port ${PORT}`);
  setTimeout(initDB, 2000);
  setTimeout(initRedis, 2000);
});
