const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const pool = new Pool({
  host: process.env.DB_HOST || 'postgres',
  user: process.env.DB_USER || 'restaurant',
  password: process.env.DB_PASSWORD || 'password',
  database: process.env.DB_NAME || 'restaurantdb',
  port: 5432,
});

// Initialize database
async function initDB() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS tables (
        id SERIAL PRIMARY KEY,
        table_number INTEGER UNIQUE NOT NULL,
        capacity INTEGER NOT NULL,
        status VARCHAR(50) DEFAULT 'available'
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS reservations (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        table_id INTEGER REFERENCES tables(id),
        reservation_date DATE NOT NULL,
        reservation_time TIME NOT NULL,
        guest_count INTEGER NOT NULL,
        status VARCHAR(50) DEFAULT 'confirmed',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Insert sample tables if empty
    const count = await pool.query('SELECT COUNT(*) FROM tables');
    if (count.rows[0].count === '0') {
      await pool.query(`
        INSERT INTO tables (table_number, capacity, status) VALUES
        (1, 2, 'available'),
        (2, 4, 'available'),
        (3, 4, 'available'),
        (4, 6, 'available'),
        (5, 8, 'available')
      `);
      console.log('Sample tables added');
    }

    console.log('Table Service: Database initialized');
  } catch (err) {
    console.error('Database init error:', err);
  }
}

// Get all tables
app.get('/tables', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM tables ORDER BY table_number');
    res.json({ success: true, tables: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Create reservation
app.post('/reservations', async (req, res) => {
  try {
    const { user_id, table_id, reservation_date, reservation_time, guest_count } = req.body;

    const result = await pool.query(
      'INSERT INTO reservations (user_id, table_id, reservation_date, reservation_time, guest_count) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [user_id, table_id, reservation_date, reservation_time, guest_count]
    );

    res.json({ success: true, reservation: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get all reservations
app.get('/reservations', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM reservations ORDER BY reservation_date DESC, reservation_time DESC');
    res.json({ success: true, reservations: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get reservations by user
app.get('/reservations/user/:user_id', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM reservations WHERE user_id = $1 ORDER BY reservation_date DESC', [req.params.user_id]);
    res.json({ success: true, reservations: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Update reservation status
app.put('/reservations/:id', async (req, res) => {
  try {
    const { status } = req.body;
    await pool.query('UPDATE reservations SET status = $1 WHERE id = $2', [status, req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'table-service' });
});

const PORT = 3004;
app.listen(PORT, () => {
  console.log(`Table Service running on port ${PORT}`);
  setTimeout(initDB, 2000);
});
