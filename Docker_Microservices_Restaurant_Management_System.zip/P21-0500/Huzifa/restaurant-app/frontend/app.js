const API_URL = '/api';
let currentUser = null;
let cart = [];

// Check if user is logged in
function checkAuth() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');

    if (token && user) {
        currentUser = JSON.parse(user);
        document.getElementById('user-info').textContent = `Welcome, ${currentUser.username}`;
        document.getElementById('logout-btn').style.display = 'inline-block';
        document.querySelector('#auth-section button:nth-child(1)').style.display = 'none';
        document.querySelector('#auth-section button:nth-child(2)').style.display = 'none';

        document.getElementById('order-section').style.display = 'block';
        document.getElementById('orders-section').style.display = 'block';
        document.getElementById('reservation-section').style.display = 'block';
    }
}

// Login
function showLogin() {
    document.getElementById('login-modal').style.display = 'flex';
}

async function login() {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    const data = await response.json();

    if (data.success) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        location.reload();
    } else {
        alert('Login failed: ' + data.error);
    }
}

// Register
function showRegister() {
    document.getElementById('register-modal').style.display = 'flex';
}

async function register() {
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;
    const role = document.getElementById('register-role').value;

    const response = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, role })
    });

    const data = await response.json();

    if (data.success) {
        alert('Registration successful! Please login.');
        closeModal();
    } else {
        alert('Registration failed: ' + data.error);
    }
}

// Logout
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    location.reload();
}

function closeModal() {
    document.getElementById('login-modal').style.display = 'none';
    document.getElementById('register-modal').style.display = 'none';
}

// Load menu
async function loadMenu() {
    const response = await fetch(`${API_URL}/menu/menu`);
    const data = await response.json();

    if (data.success) {
        const menuList = document.getElementById('menu-list');
        menuList.innerHTML = data.items.map(item => `
            <div class="menu-card">
                <p class="category-badge">${item.category}</p>
                <h3>${item.name}</h3>
                <p class="price">Rs. ${item.price}</p>
                <button onclick="addToCart('${item._id}', '${item.name}', ${item.price})">Add to Cart</button>
            </div>
        `).join('');
    }
}

// Cart functions
function addToCart(id, name, price) {
    if (!currentUser) {
        alert('Please login to order');
        return;
    }

    cart.push({ id, name, price });
    updateCart();
}

function updateCart() {
    const cartDiv = document.getElementById('cart');
    const total = cart.reduce((sum, item) => sum + item.price, 0);

    cartDiv.innerHTML = `
        <div id="cart-items">
            ${cart.map((item, index) => `
                <div>${item.name} - Rs. ${item.price} <button onclick="removeFromCart(${index})">Remove</button></div>
            `).join('')}
        </div>
        <strong>Total: Rs. ${total}</strong>
    `;
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
}

// Place order
async function placeOrder() {
    if (cart.length === 0) {
        alert('Cart is empty');
        return;
    }

    const total = cart.reduce((sum, item) => sum + item.price, 0);

    const response = await fetch(`${API_URL}/order/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            user_id: currentUser.id,
            items: cart,
            total_amount: total
        })
    });

    const data = await response.json();

    if (data.success) {
        alert('Order placed successfully!');
        cart = [];
        updateCart();
        loadOrders();
    }
}

// Load orders
async function loadOrders() {
    const response = await fetch(`${API_URL}/order/orders`);
    const data = await response.json();

    if (data.success) {
        const ordersList = document.getElementById('orders-list');
        ordersList.innerHTML = data.orders.map(order => `
            <div class="order-card">
                <p><strong>Order #${order.id}</strong></p>
                <p>Total: Rs. ${order.total_amount}</p>
                <p>Status: ${order.status}</p>
                <p>Date: ${new Date(order.created_at).toLocaleString()}</p>
            </div>
        `).join('');
    }
}

// Load tables
async function loadTables() {
    const response = await fetch(`${API_URL}/table/tables`);
    const data = await response.json();

    if (data.success) {
        const tablesList = document.getElementById('tables-list');
        const tableSelect = document.getElementById('table-select');

        tablesList.innerHTML = data.tables.map(table => `
            <div class="menu-card">
                <h3>Table ${table.table_number}</h3>
                <p>Capacity: ${table.capacity} people</p>
                <p>Status: ${table.status}</p>
            </div>
        `).join('');

        tableSelect.innerHTML = data.tables.map(table =>
            `<option value="${table.id}">Table ${table.table_number} (${table.capacity} seats)</option>`
        ).join('');
    }
}

// Reserve table
async function reserveTable() {
    if (!currentUser) {
        alert('Please login to reserve');
        return;
    }

    const table_id = document.getElementById('table-select').value;
    const reservation_date = document.getElementById('reservation-date').value;
    const reservation_time = document.getElementById('reservation-time').value;
    const guest_count = document.getElementById('guest-count').value;

    const response = await fetch(`${API_URL}/table/reservations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            user_id: currentUser.id,
            table_id,
            reservation_date,
            reservation_time,
            guest_count
        })
    });

    const data = await response.json();

    if (data.success) {
        alert('Table reserved successfully!');
        document.getElementById('reservation-date').value = '';
        document.getElementById('reservation-time').value = '';
        document.getElementById('guest-count').value = '';
    } else {
        alert('Reservation failed: ' + data.error);
    }
}

// Initialize
checkAuth();
loadMenu();
loadTables();
if (currentUser) {
    loadOrders();
}
