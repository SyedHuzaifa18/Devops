#!/bin/bash

echo "🍽️  Restaurant Management System - Docker Setup"
echo "=============================================="
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

# Check Docker permissions
if ! docker ps &> /dev/null; then
    echo "⚠️  Docker permission denied. You may need to:"
    echo "   1. Add your user to docker group: sudo usermod -aG docker $USER"
    echo "   2. Log out and log back in, or run: newgrp docker"
    echo ""
    echo "Attempting to run with sudo..."
    DOCKER_CMD="sudo docker-compose"
else
    DOCKER_CMD="docker-compose"
fi

echo "📦 Building and starting all containers..."
echo ""

$DOCKER_CMD up -d --build

echo ""
echo "⏳ Waiting for services to be ready..."
sleep 10

echo ""
echo "✅ Checking container status..."
$DOCKER_CMD ps

echo ""
echo "=============================================="
echo "🎉 Restaurant Management System is running!"
echo "=============================================="
echo ""
echo "📍 Access Points:"
echo "   🌐 Main Application: http://localhost"
echo "   🎨 Frontend (direct): http://localhost:8080"
echo "   🔐 Auth Service: http://localhost:3001/health"
echo "   🍔 Menu Service: http://localhost:3002/health"
echo "   📦 Order Service: http://localhost:3003/health"
echo "   🪑 Table Service: http://localhost:3004/health"
echo "   💾 Database UI (Adminer): http://localhost:8081"
echo ""
echo "📊 Database Credentials (for Adminer):"
echo "   System: PostgreSQL"
echo "   Server: postgres"
echo "   Username: restaurant"
echo "   Password: password"
echo "   Database: restaurantdb"
echo ""
echo "🛠️  Useful Commands:"
echo "   View logs: $DOCKER_CMD logs -f"
echo "   Stop services: $DOCKER_CMD down"
echo "   Restart: $DOCKER_CMD restart"
echo ""
