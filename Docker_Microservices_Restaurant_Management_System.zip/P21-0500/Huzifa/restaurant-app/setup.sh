#!/bin/bash

echo "🚀 Restaurant Management System - Automated Setup"
echo "=================================================="
echo ""

# Check if Docker is running
if ! docker ps > /dev/null 2>&1; then
    echo "❌ Docker is not running or you don't have permission"
    echo "Run: sudo usermod -aG docker $USER && newgrp docker"
    exit 1
fi

# Start containers
echo "📦 Building and starting all containers..."
docker-compose up -d --build

# Wait for databases
echo "⏳ Waiting 30 seconds for databases to initialize..."
sleep 30

# Create PostgreSQL tables
echo "🗄️  Creating database tables..."

docker-compose exec -T postgres psql -U restaurant -d restaurantdb << 'EOF'
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  items TEXT NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tables (
  id SERIAL PRIMARY KEY,
  table_number INTEGER UNIQUE NOT NULL,
  capacity INTEGER NOT NULL,
  status VARCHAR(50) DEFAULT 'available'
);

CREATE TABLE IF NOT EXISTS reservations (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  table_id INTEGER REFERENCES tables(id),
  reservation_date DATE NOT NULL,
  reservation_time TIME NOT NULL,
  guest_count INTEGER NOT NULL,
  status VARCHAR(50) DEFAULT 'confirmed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO tables (table_number, capacity, status) VALUES
(1, 2, 'available'),
(2, 4, 'available'),
(3, 4, 'available'),
(4, 6, 'available'),
(5, 8, 'available')
ON CONFLICT (table_number) DO NOTHING;
EOF

if [ $? -eq 0 ]; then
    echo "✅ Database tables created successfully"
else
    echo "❌ Failed to create database tables"
    exit 1
fi

# Restart services
echo "🔄 Restarting microservices..."
docker-compose restart auth-service menu-service order-service table-service

# Wait for restart
echo "⏳ Waiting for services to restart..."
sleep 10

# Show status
echo ""
echo "=================================================="
echo "✅ Setup Complete!"
echo "=================================================="
echo ""
echo "📊 Container Status:"
docker-compose ps
echo ""
echo "🌐 Access Points:"
echo "   Main Application: http://localhost"
echo "   Database UI:      http://localhost:8081"
echo ""
echo "🔐 Default Credentials (Adminer):"
echo "   System:   PostgreSQL"
echo "   Server:   postgres"
echo "   Username: restaurant"
echo "   Password: password"
echo "   Database: restaurantdb"
echo ""
echo "👤 Create User Account:"
echo "   1. Go to http://localhost"
echo "   2. Click 'Register'"
echo "   3. Create your account"
echo "   4. Login and enjoy!"
echo ""
echo "🎉 Restaurant Management System is ready!"
echo ""
